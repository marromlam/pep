#include <iostream>
#include <tbb/parallel_for.h>

using namespace std;
using namespace tbb;

int main(void) {
  tbb::parallel_for(0, 4, [&](size_t i) { cout << "Hi! This is number " << i << endl; });
  return 0;
}

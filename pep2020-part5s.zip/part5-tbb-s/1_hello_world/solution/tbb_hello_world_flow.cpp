/* with code from the Intel website */

#include <iostream>
#include "tbb/flow_graph.h"

using namespace std;
using namespace tbb::flow;

int main(int argc, char *argv[]) {
  graph g;
  
  // TODO
  continue_node<continue_msg> n1(g, [](const continue_msg &) { cout << "Hello "; });
  continue_node<continue_msg> n2(g, [](const continue_msg &) { cout << "World" << endl; });
  
  // TODO: add an edge and send a message to the first node
  make_edge(n1, n2);
  n1.try_put(continue_msg());
  g.wait_for_all();
  
  return 0;
}

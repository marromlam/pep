#!/usr/bin/env python

def decrement(n):
  while n>0:
    n -= 1

decrement(1e8)
decrement(1e8)
